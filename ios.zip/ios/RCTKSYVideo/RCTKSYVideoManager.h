//
//  RCTKSYVideoManager.h
//  RCTKSYVideo
//
//  Created by mayudong on 2017/11/27.
//  Copyright © 2017年 mayudong. All rights reserved.
//

#import <React/RCTViewManager.h>

@interface RCTKSYVideoManager : RCTViewManager

@end
